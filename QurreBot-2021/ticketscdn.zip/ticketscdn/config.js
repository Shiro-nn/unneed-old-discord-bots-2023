module.exports = {
    safe: 'https',
    host: 'bot.fydne.xyz',
    id: 1,
    last: true,
}