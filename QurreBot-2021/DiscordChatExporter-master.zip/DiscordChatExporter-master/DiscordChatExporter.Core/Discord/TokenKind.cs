﻿namespace DiscordChatExporter.Core.Discord;

public enum TokenKind
{
    User,
    Bot
}