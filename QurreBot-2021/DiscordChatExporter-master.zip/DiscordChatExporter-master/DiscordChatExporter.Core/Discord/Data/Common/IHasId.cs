﻿namespace DiscordChatExporter.Core.Discord.Data.Common;

public interface IHasId
{
    Snowflake Id { get; }
}