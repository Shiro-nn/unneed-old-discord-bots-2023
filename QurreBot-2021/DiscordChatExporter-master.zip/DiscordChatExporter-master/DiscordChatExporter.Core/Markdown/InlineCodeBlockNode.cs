﻿namespace DiscordChatExporter.Core.Markdown;

internal record InlineCodeBlockNode(string Code) : MarkdownNode;