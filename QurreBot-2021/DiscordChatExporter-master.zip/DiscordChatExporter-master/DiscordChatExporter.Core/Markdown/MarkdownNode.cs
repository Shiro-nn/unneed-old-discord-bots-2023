﻿namespace DiscordChatExporter.Core.Markdown;

internal abstract record MarkdownNode;