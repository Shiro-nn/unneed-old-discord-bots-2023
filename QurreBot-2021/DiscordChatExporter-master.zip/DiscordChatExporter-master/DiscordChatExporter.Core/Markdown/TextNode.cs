﻿namespace DiscordChatExporter.Core.Markdown;

internal record TextNode(string Text) : MarkdownNode;