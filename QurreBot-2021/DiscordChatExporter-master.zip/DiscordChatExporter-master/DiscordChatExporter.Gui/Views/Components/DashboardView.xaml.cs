﻿namespace DiscordChatExporter.Gui.Views.Components;

public partial class DashboardView
{
    public DashboardView()
    {
        InitializeComponent();
    }
}