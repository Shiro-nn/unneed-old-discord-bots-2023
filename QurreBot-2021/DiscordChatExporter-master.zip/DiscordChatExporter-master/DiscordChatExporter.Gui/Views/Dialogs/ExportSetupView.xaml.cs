namespace DiscordChatExporter.Gui.Views.Dialogs;

public partial class ExportSetupView
{
    public ExportSetupView()
    {
        InitializeComponent();
    }
}